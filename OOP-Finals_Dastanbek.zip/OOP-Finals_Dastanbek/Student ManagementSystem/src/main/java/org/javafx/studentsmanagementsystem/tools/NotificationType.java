
package main.java.org.javafx.studentsmanagementsystem.tools;


public enum NotificationType {

	CONFIRM,

	ERROR,

	INFORMATION,

	SIMPLE,

	SUCCESS,


	WARNING;

}
