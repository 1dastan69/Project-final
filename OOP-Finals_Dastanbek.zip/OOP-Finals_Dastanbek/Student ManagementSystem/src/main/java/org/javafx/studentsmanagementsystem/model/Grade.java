package main.java.org.javafx.studentsmanagementsystem.model;

public class Grade {
	private Integer studId;
	private String studName;
	private Integer grade;
	
	public Integer getStudId() {
		return studId;
	}
	
	public void setStudId(Integer studId) {
		this.studId = studId;
	}
	
	public String getStudName() {
		return studName;
	}
	
	public void setStudName(String studName) {
		this.studName = studName;
	}
	
	public Integer getGrade() {
		return grade;
	}
	
	public void setGrade(Integer grade) {
		this.grade = grade;
	}
	
}
